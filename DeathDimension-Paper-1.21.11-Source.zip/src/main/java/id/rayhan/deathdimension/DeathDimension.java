package id.rayhan.deathdimension;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.command.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.generator.ChunkGenerator;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.io.IOException;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public final class DeathDimension extends JavaPlugin implements Listener, CommandExecutor {
    private final Map<UUID, Long> punishments = new ConcurrentHashMap<>();
    private final LegacyComponentSerializer legacy = LegacyComponentSerializer.legacyAmpersand();
    private World realm;
    private NamespacedKey particleKey;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        loadPunishments();
        createRealm();
        Bukkit.getPluginManager().registerEvents(this, this);
        Objects.requireNonNull(getCommand("deathdimension")).setExecutor(this);
        startTicker();
        getLogger().info("DeathDimension enabled.");
    }

    @Override
    public void onDisable() {
        savePunishments();
    }

    private void createRealm() {
        String name = getConfig().getString("realm.world-name", "death_void");
        realm = Bukkit.getWorld(name);
        if (realm == null) {
            WorldCreator creator = new WorldCreator(name);
            creator.environment(World.Environment.NORMAL);
            creator.type(WorldType.NORMAL);
            creator.generator(new EmptyGenerator());
            realm = creator.createWorld();
        }
        if (realm != null) {
            realm.setGameRule(GameRule.DO_MOB_SPAWNING, false);
            realm.setGameRule(GameRule.DO_WEATHER_CYCLE, false);
            realm.setGameRule(GameRule.DO_DAYLIGHT_CYCLE, false);
            realm.setTime(18000);
            realm.setStorm(false);
            realm.setThundering(false);
            realm.setSpawnLocation(spawnLocation());
            buildPlatform();
        } else {
            getLogger().severe("Could not create the death realm world.");
        }
    }

    private Location spawnLocation() {
        if (realm == null) return Bukkit.getWorlds().get(0).getSpawnLocation();
        return new Location(realm,
                getConfig().getDouble("realm.spawn-x", 0.5),
                getConfig().getDouble("realm.spawn-y", 80.0),
                getConfig().getDouble("realm.spawn-z", 0.5));
    }

    private void buildPlatform() {
        Location center = spawnLocation();
        int radius = Math.max(1, getConfig().getInt("realm.platform-radius", 3));
        Material material;
        try {
            material = Material.valueOf(getConfig().getString("realm.platform-block", "BLACKSTONE").toUpperCase(Locale.ROOT));
            if (!material.isBlock()) material = Material.BLACKSTONE;
        } catch (IllegalArgumentException ex) {
            material = Material.BLACKSTONE;
        }
        int y = center.getBlockY() - 1;
        for (int x = -radius; x <= radius; x++) {
            for (int z = -radius; z <= radius; z++) {
                Block block = realm.getBlockAt(center.getBlockX() + x, y, center.getBlockZ() + z);
                block.setType(material, false);
            }
        }
        realm.getBlockAt(center).setType(Material.AIR, false);
        realm.getBlockAt(center.clone().add(0, 1, 0)).setType(Material.AIR, false);
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onDeath(PlayerDeathEvent event) {
        Player player = event.getEntity();
        if (punishments.containsKey(player.getUniqueId())) return;
        long duration = Math.max(1, getConfig().getLong("punishment-seconds", 10800));
        punishments.put(player.getUniqueId(), System.currentTimeMillis() + duration * 1000L);
        savePunishments();
        player.sendMessage(msg("sent"));
        player.showTitle(net.kyori.adventure.title.Title.title(
                color(getConfig().getString("messages.title", "&4KAMU MATI")),
                color(getConfig().getString("messages.subtitle", "&7Jiwamu terperangkap di kehampaan..."))));
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent event) {
        Player player = event.getPlayer();
        if (punishments.containsKey(player.getUniqueId()) && realm != null) {
            event.setRespawnLocation(spawnLocation());
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        Long expiry = punishments.get(player.getUniqueId());
        if (expiry == null) return;
        if (expiry <= System.currentTimeMillis()) {
            release(player);
        } else if (realm != null) {
            Bukkit.getScheduler().runTask(this, () -> {
                if (player.isOnline() && punishments.containsKey(player.getUniqueId())) {
                    player.teleport(spawnLocation());
                    player.sendMessage(msg("sent"));
                }
            });
        }
    }

    private void startTicker() {
        new BukkitRunnable() {
            @Override public void run() {
                long now = System.currentTimeMillis();
                for (Map.Entry<UUID, Long> entry : new HashMap<>(punishments).entrySet()) {
                    Player player = Bukkit.getPlayer(entry.getKey());
                    if (entry.getValue() <= now) {
                        if (player != null && player.isOnline()) release(player);
                        else punishments.remove(entry.getKey());
                        savePunishments();
                        continue;
                    }
                    if (player != null && player.isOnline()) {
                        long seconds = Math.max(0, (entry.getValue() - now + 999) / 1000);
                        player.sendActionBar(color(getConfig().getString("messages.actionbar", "&bWaktu tersisa: &f%time%")
                                .replace("%time%", format(seconds))));
                        if (player.getWorld().equals(realm) && getConfig().getBoolean("realm.ambient-particles", true)) {
                            Location at = player.getLocation().add(0, 1, 0);
                            player.getWorld().spawnParticle(Particle.SOUL, at, 3, 0.45, 0.6, 0.45, 0.01);
                        }
                        if (realm != null && !player.getWorld().equals(realm)) player.teleport(spawnLocation());
                    }
                }
            }
        }.runTaskTimer(this, 20L, 20L);
    }

    private String format(long seconds) {
        long h = seconds / 3600, m = (seconds % 3600) / 60, s = seconds % 60;
        return String.format(Locale.ROOT, "%02d:%02d:%02d", h, m, s);
    }

    private void release(Player player) {
        punishments.remove(player.getUniqueId());
        savePunishments();
        World main = Bukkit.getWorld(getConfig().getString("main-world", Bukkit.getWorlds().get(0).getName()));
        if (main == null) main = Bukkit.getWorlds().get(0);
        player.teleport(main.getSpawnLocation());
        player.sendMessage(msg("released"));
        player.sendActionBar(Component.empty());
    }

    private Component color(String input) {
        return legacy.deserialize(input == null ? "" : input);
    }

    private String msg(String key) {
        return ChatColor.translateAlternateColorCodes('&',
                getConfig().getString("messages." + key, ""));
    }

    private void loadPunishments() {
        var section = getConfig().getConfigurationSection("punishments");
        if (section == null) return;
        for (String id : section.getKeys(false)) {
            try { punishments.put(UUID.fromString(id), section.getLong(id)); }
            catch (IllegalArgumentException ignored) {}
        }
    }

    private void savePunishments() {
        for (String key : new HashSet<>(Objects.requireNonNullElse(
                getConfig().getConfigurationSection("punishments"), getConfig().createSection("punishments")).getKeys(false))) {
            getConfig().set("punishments." + key, null);
        }
        for (var entry : punishments.entrySet())
            getConfig().set("punishments." + entry.getKey(), entry.getValue());
        saveConfig();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("deathdimension.admin")) {
            sender.sendMessage(msg("no-permission")); return true;
        }
        if (args.length == 0) { sender.sendMessage(msg("usage")); return true; }
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "reload" -> { reloadConfig(); createRealm(); sender.sendMessage(msg("reloaded")); }
            case "release", "send" -> {
                if (args.length < 2) { sender.sendMessage(msg("usage")); return true; }
                Player target = Bukkit.getPlayerExact(args[1]);
                if (target == null) { sender.sendMessage(msg("player-not-found")); return true; }
                if (args[0].equalsIgnoreCase("release")) {
                    if (!punishments.containsKey(target.getUniqueId())) { sender.sendMessage(msg("not-punished")); return true; }
                    release(target); sender.sendMessage(msg("manually-released"));
                } else {
                    long duration = Math.max(1, getConfig().getLong("punishment-seconds", 10800));
                    punishments.put(target.getUniqueId(), System.currentTimeMillis() + duration * 1000L);
                    if (realm != null) target.teleport(spawnLocation());
                    savePunishments();
                    sender.sendMessage(ChatColor.GREEN + "Player sent to the death realm.");
                }
            }
            default -> sender.sendMessage(msg("usage"));
        }
        return true;
    }

    private static final class EmptyGenerator extends ChunkGenerator {
        @Override
        public ChunkData generateChunkData(World world, Random random, int x, int z, BiomeGrid biome) {
            return createChunkData(world);
        }
    }
}
